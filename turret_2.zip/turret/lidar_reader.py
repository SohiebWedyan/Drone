"""
RPLiDAR reader running in a background thread.
Continuously scans and stores the latest distance reading
for any requested angle so the main loop never blocks.
"""

import math
import threading
import time

try:
    from rplidar import RPLidar as _RPLidar
    RPLIDAR_AVAILABLE = True
except ImportError:
    RPLIDAR_AVAILABLE = False
    print("[LiDAR] rplidar library not found — running in MOCK mode.")


class LidarReader:

    def __init__(self, port: str = "/dev/ttyUSB0", max_range: float = 10.0):
        """
        port      : serial port the LiDAR is connected to
        max_range : discard readings beyond this distance (metres)
        """
        self.max_range = max_range

        # angle (int degrees 0-359) → distance (metres)
        self._scan: dict[int, float] = {}
        self._lock = threading.Lock()
        self._running = False
        self._thread  = None

        if RPLIDAR_AVAILABLE:
            try:
                self._lidar = _RPLidar(port, baudrate=115200)
            except Exception as e:
                print(f"[LiDAR] Device not found on {port}: {e}")
                print("[LiDAR] Running in MOCK mode.")
                self._lidar = None
        else:
            self._lidar = None

    # ------------------------------------------------------------------
    def start(self):
        self._running = True
        self._thread = threading.Thread(
            target=self._scan_loop,
            daemon=True
        )
        self._thread.start()
        print("[LiDAR] Background scan started.")

    # ------------------------------------------------------------------
    def stop(self):
        self._running = False
        if self._lidar:
            try:
                self._lidar.stop()
                self._lidar.disconnect()
            except Exception:
                pass

    # ------------------------------------------------------------------
    def _scan_loop(self):
        if not RPLIDAR_AVAILABLE or self._lidar is None:
            self._mock_loop()
            return

        try:
            for scan in self._lidar.iter_scans():
                if not self._running:
                    break
                with self._lock:
                    for _, angle, dist_mm in scan:
                        dist_m = dist_mm / 1000.0
                        if 0.1 < dist_m < self.max_range:
                            self._scan[int(angle) % 360] = dist_m
        except Exception as e:
            print(f"[LiDAR] Scan error: {e}")

    # ------------------------------------------------------------------
    def _mock_loop(self):
        """Simulates a target at ~2 m in front for testing without hardware."""
        import random
        while self._running:
            with self._lock:
                for angle in range(360):
                    self._scan[angle] = 2.0 + random.uniform(-0.05, 0.05)
            time.sleep(0.1)

    # ------------------------------------------------------------------
    def distance_at_angle(self, angle_deg: float, window: int = 3) -> float:
        """
        Returns distance in metres closest to angle_deg.
        Averages over ±window degrees to reduce noise.
        Returns 0.0 if no data is available.
        """
        base = int(round(angle_deg)) % 360
        samples = []

        with self._lock:
            for offset in range(-window, window + 1):
                a = (base + offset) % 360
                if a in self._scan:
                    samples.append(self._scan[a])

        if not samples:
            return 0.0

        # Use median to reject outlier reflections
        samples.sort()
        return samples[len(samples) // 2]

    # ------------------------------------------------------------------
    def distance_for_pixel(
        self,
        cx: int,
        frame_width: int,
        hfov_deg: float = 60.0
    ) -> float:
        """
        Converts a pixel X position to a LiDAR angle and returns distance.

        cx          : target X pixel in the frame
        frame_width : total frame width in pixels
        hfov_deg    : horizontal field of view of the camera in degrees
        """
        # Map pixel offset from centre to angle offset
        offset_norm = (cx - frame_width / 2) / (frame_width / 2)
        angle_offset = offset_norm * (hfov_deg / 2)

        # LiDAR 0° is straight ahead; positive offset → right
        lidar_angle = (angle_offset) % 360

        return self.distance_at_angle(lidar_angle)
