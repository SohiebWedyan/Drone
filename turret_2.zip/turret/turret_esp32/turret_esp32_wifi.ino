// ======================================================
// AI TRACKING TURRET — ESP32 WiFi Version
// Receives UDP packets from Raspberry Pi over WiFi
// Format: "320,240,2.45\n"  or  "L:\n"
// ======================================================

#include <WiFi.h>
#include <WiFiUdp.h>
#include <AccelStepper.h>

// ======================================================
// WiFi SETTINGS — change to your network
// ======================================================

const char* WIFI_SSID     = "YOUR_WIFI_NAME";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const int   UDP_PORT      = 5005;

// ======================================================
// STEPPER PINS
// ======================================================

#define PAN_STEP_PIN   25
#define PAN_DIR_PIN    26
#define TILT_STEP_PIN  18
#define TILT_DIR_PIN   19

// ======================================================
// FIRE PIN
// ======================================================

#define FIRE_PIN 12

// ======================================================
// STEPPERS
// ======================================================

AccelStepper panStepper(AccelStepper::DRIVER, PAN_STEP_PIN,  PAN_DIR_PIN);
AccelStepper tiltStepper(AccelStepper::DRIVER, TILT_STEP_PIN, TILT_DIR_PIN);

// ======================================================
// FRAME DIMENSIONS
// ======================================================

const int FRAME_W  = 640;
const int FRAME_H  = 480;
const int CENTER_X = FRAME_W / 2;
const int CENTER_Y = FRAME_H / 2;

// ======================================================
// MOTOR LIMITS
// ======================================================

const long PAN_LIMIT  = 50000;
const long TILT_LIMIT = 2000;

// ======================================================
// TARGET STATE
// ======================================================

int   camX           = CENTER_X;
int   camY           = CENTER_Y;
float distanceM      = 0.0;
bool  targetDetected = false;

const unsigned long TARGET_TIMEOUT_MS = 500;
unsigned long       lastDataTime      = 0;

// ======================================================
// PID
// ======================================================

float kp_pan  = 0.8,  kp_tilt  = 0.8;
float ki_pan  = 0.01, ki_tilt  = 0.01;
float kd_pan  = 0.2,  kd_tilt  = 0.2;

float prevErrorPan  = 0, prevErrorTilt  = 0;
float integralPan   = 0, integralTilt   = 0;

const float INTEGRAL_LIMIT = 500.0;

long targetPan  = 0;
long targetTilt = 0;

// ======================================================
// FIRE
// ======================================================

const unsigned long FIRE_COOLDOWN_MS = 1500;
const unsigned long FIRE_PULSE_MS    = 200;

unsigned long lastFireTime  = 0;
unsigned long fireStartTime = 0;
bool          firing        = false;

// ======================================================
// UDP
// ======================================================

WiFiUDP udp;
char    packetBuffer[64];

// ======================================================
// SETUP
// ======================================================

void setup() {
    Serial.begin(115200);

    // Stepper config
    panStepper.setMaxSpeed(2500);
    panStepper.setAcceleration(1500);
    tiltStepper.setMaxSpeed(2500);
    tiltStepper.setAcceleration(1500);

    // Fire pin
    pinMode(FIRE_PIN, OUTPUT);
    digitalWrite(FIRE_PIN, LOW);

    // Connect to WiFi
    Serial.print("Connecting to WiFi");
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

    while (WiFi.status() != WL_CONNECTED) {
        delay(500);
        Serial.print(".");
    }

    Serial.println();
    Serial.println("=================================");
    Serial.println("WiFi Connected!");
    Serial.print("ESP32 IP: ");
    Serial.println(WiFi.localIP());
    Serial.print("Listening on UDP port: ");
    Serial.println(UDP_PORT);
    Serial.println("=================================");

    udp.begin(UDP_PORT);
}

// ======================================================
// MAIN LOOP
// ======================================================

void loop() {
    readUDP();

    if (millis() - lastDataTime > TARGET_TIMEOUT_MS) {
        if (targetDetected) {
            targetDetected = false;
            resetPID();
            Serial.println("[INFO] Target lost (timeout)");
        }
    }

    if (targetDetected) {
        trackTarget();
        autoFire();
    }

    panStepper.run();
    tiltStepper.run();
    handleFirePulse();
}

// ======================================================
// READ UDP PACKET
// ======================================================

void readUDP() {
    int packetSize = udp.parsePacket();
    if (packetSize == 0) return;

    int len = udp.read(packetBuffer, sizeof(packetBuffer) - 1);
    if (len <= 0) return;
    packetBuffer[len] = '\0';

    String data = String(packetBuffer);
    data.trim();

    // Lost-target signal
    if (data.startsWith("L:")) {
        targetDetected = false;
        resetPID();
        Serial.println("[INFO] Target lost (Pi signal)");
        return;
    }

    // Coordinate packet
    int firstComma  = data.indexOf(',');
    int secondComma = data.indexOf(',', firstComma + 1);

    if (firstComma < 1 || secondComma < 1) return;

    int   parsedX = data.substring(0, firstComma).toInt();
    int   parsedY = data.substring(firstComma + 1, secondComma).toInt();
    float parsedD = data.substring(secondComma + 1).toFloat();

    if (parsedX < 0 || parsedX > FRAME_W) return;
    if (parsedY < 0 || parsedY > FRAME_H) return;
    if (parsedD < 0.0 || parsedD > 20.0)  return;

    camX      = parsedX;
    camY      = parsedY;
    distanceM = parsedD;

    targetDetected = true;
    lastDataTime   = millis();

    Serial.print("X:"); Serial.print(camX);
    Serial.print(" Y:"); Serial.print(camY);
    Serial.print(" D:"); Serial.println(distanceM);
}

// ======================================================
// PID TRACKING
// ======================================================

void trackTarget() {
    float errorPan  = (float)(CENTER_X - camX);
    float errorTilt = (float)(CENTER_Y - camY);

    integralPan  = constrain(integralPan  + errorPan,  -INTEGRAL_LIMIT, INTEGRAL_LIMIT);
    integralTilt = constrain(integralTilt + errorTilt, -INTEGRAL_LIMIT, INTEGRAL_LIMIT);

    float dPan  = errorPan  - prevErrorPan;
    float dTilt = errorTilt - prevErrorTilt;

    float outPan  = kp_pan  * errorPan  + ki_pan  * integralPan  + kd_pan  * dPan;
    float outTilt = kp_tilt * errorTilt + ki_tilt * integralTilt + kd_tilt * dTilt;

    targetPan  += (long)outPan;
    targetTilt += (long)outTilt;

    targetPan  = constrain(targetPan,  -PAN_LIMIT,  PAN_LIMIT);
    targetTilt = constrain(targetTilt, -TILT_LIMIT, TILT_LIMIT);

    panStepper.moveTo(targetPan);
    tiltStepper.moveTo(targetTilt);

    prevErrorPan  = errorPan;
    prevErrorTilt = errorTilt;
}

// ======================================================
// RESET PID
// ======================================================

void resetPID() {
    prevErrorPan  = 0;
    prevErrorTilt = 0;
    integralPan   = 0;
    integralTilt  = 0;
}

// ======================================================
// AUTO FIRE
// ======================================================

void autoFire() {
    if (firing) return;

    bool centeredX    = abs(camX - CENTER_X) < 25;
    bool centeredY    = abs(camY - CENTER_Y) < 25;
    bool validRange   = distanceM > 0.5 && distanceM < 5.0;
    bool cooldownDone = (millis() - lastFireTime) > FIRE_COOLDOWN_MS;

    if (centeredX && centeredY && validRange && cooldownDone) {
        Serial.println("FIRE!");
        digitalWrite(FIRE_PIN, HIGH);
        firing        = true;
        fireStartTime = millis();
        lastFireTime  = millis();
    }
}

// ======================================================
// FIRE PULSE HANDLER
// ======================================================

void handleFirePulse() {
    if (firing && (millis() - fireStartTime >= FIRE_PULSE_MS)) {
        digitalWrite(FIRE_PIN, LOW);
        firing = false;
    }
}
