// ======================================================
// AI TRACKING TURRET — ESP32
// Receives: X,Y,DISTANCE\n  or  L:\n  from Raspberry Pi
// Controls: Pan + Tilt stepper motors via PID
// ======================================================

#include <AccelStepper.h>

// ======================================================
// STEPPER PINS
// ======================================================

#define PAN_STEP_PIN    25
#define PAN_DIR_PIN     26

#define TILT_STEP_PIN   18
#define TILT_DIR_PIN    19

// ======================================================
// UART PINS (Serial2 → Raspberry Pi)
// Serial  (USB) is kept for debug output only
// ======================================================

#define PI_RX_PIN   16   // ESP32 RX2 ← Pi TX
#define PI_TX_PIN   17   // ESP32 TX2 → Pi RX

// ======================================================
// FIRE SYSTEM
// ======================================================

#define FIRE_PIN 12

// ======================================================
// STEPPERS
// ======================================================

AccelStepper panStepper(
    AccelStepper::DRIVER,
    PAN_STEP_PIN,
    PAN_DIR_PIN
);

AccelStepper tiltStepper(
    AccelStepper::DRIVER,
    TILT_STEP_PIN,
    TILT_DIR_PIN
);

// ======================================================
// FRAME DIMENSIONS  (must match Python FRAME_W / FRAME_H)
// ======================================================

const int FRAME_W  = 640;
const int FRAME_H  = 480;
const int CENTER_X = FRAME_W / 2;
const int CENTER_Y = FRAME_H / 2;

// ======================================================
// MOTOR LIMITS  (steps — tune to your gear ratio)
// ======================================================

const long PAN_LIMIT  = 50000;   // ± steps from home
const long TILT_LIMIT = 2000;

// ======================================================
// TARGET STATE
// ======================================================

int   camX        = CENTER_X;
int   camY        = CENTER_Y;
float distanceM   = 0.0;
bool  targetDetected = false;

// Timeout: declare target lost if no packet arrives within this window
const unsigned long TARGET_TIMEOUT_MS = 500;
unsigned long       lastDataTime      = 0;

// ======================================================
// PID — full PD + I with anti-windup
// ======================================================

float kp_pan  = 0.8,  kp_tilt  = 0.8;
float ki_pan  = 0.01, ki_tilt  = 0.01;
float kd_pan  = 0.2,  kd_tilt  = 0.2;

float prevErrorPan  = 0, prevErrorTilt  = 0;
float integralPan   = 0, integralTilt   = 0;

const float INTEGRAL_LIMIT = 500.0;   // anti-windup clamp

// ======================================================
// MOTOR TARGET POSITIONS
// ======================================================

long targetPan  = 0;
long targetTilt = 0;

// ======================================================
// FIRE — non-blocking pulse
// ======================================================

const unsigned long FIRE_COOLDOWN_MS = 1500;
const unsigned long FIRE_PULSE_MS    = 200;

unsigned long lastFireTime  = 0;
unsigned long fireStartTime = 0;
bool          firing        = false;

// ======================================================
// SETUP
// ======================================================

void setup() {

    // USB serial — debug only
    Serial.begin(115200);

    // Hardware UART to Raspberry Pi
    Serial2.begin(115200, SERIAL_8N1, PI_RX_PIN, PI_TX_PIN);

    // Stepper config
    panStepper.setMaxSpeed(2500);
    panStepper.setAcceleration(1500);

    tiltStepper.setMaxSpeed(2500);
    tiltStepper.setAcceleration(1500);

    // Fire pin
    pinMode(FIRE_PIN, OUTPUT);
    digitalWrite(FIRE_PIN, LOW);

    Serial.println("=================================");
    Serial.println("AI Tracking Turret — Ready");
    Serial.println("=================================");
}

// ======================================================
// MAIN LOOP
// ======================================================

void loop() {

    readSerialData();

    // Declare target lost if Pi goes silent
    if (millis() - lastDataTime > TARGET_TIMEOUT_MS) {
        if (targetDetected) {
            targetDetected = false;
            resetPID();
            Serial.println("[INFO] Target lost (timeout)");
        }
    }

    if (targetDetected) {
        trackTarget();
        autoFire();
    }

    // Always run steppers — AccelStepper needs frequent calls
    panStepper.run();
    tiltStepper.run();

    // Release fire pin if pulse duration elapsed
    handleFirePulse();
}

// ======================================================
// UART PARSER
// Accepts:
//   T packet  →  "315,220,2.45\n"
//   L packet  →  "L:\n"   (target lost signal from Pi)
// ======================================================

void readSerialData() {

    if (!Serial2.available()) return;

    String data = Serial2.readStringUntil('\n');
    data.trim();

    if (data.length() == 0) return;

    // ── Lost-target signal ─────────────────────────────────────────
    if (data.startsWith("L:")) {
        targetDetected = false;
        resetPID();
        Serial.println("[INFO] Target lost (Pi signal)");
        return;
    }

    // ── Coordinate packet ──────────────────────────────────────────
    int firstComma  = data.indexOf(',');
    int secondComma = data.indexOf(',', firstComma + 1);

    if (firstComma < 1 || secondComma < 1) return;   // malformed

    int   parsedX = data.substring(0, firstComma).toInt();
    int   parsedY = data.substring(firstComma + 1, secondComma).toInt();
    float parsedD = data.substring(secondComma + 1).toFloat();

    // Reject out-of-range values — guards against corrupt bytes
    if (parsedX < 0 || parsedX > FRAME_W)  return;
    if (parsedY < 0 || parsedY > FRAME_H)  return;
    if (parsedD < 0.0 || parsedD > 20.0)   return;

    camX      = parsedX;
    camY      = parsedY;
    distanceM = parsedD;

    targetDetected = true;
    lastDataTime   = millis();

    Serial.print("X:");   Serial.print(camX);
    Serial.print(" Y:");  Serial.print(camY);
    Serial.print(" D:");  Serial.println(distanceM);
}

// ======================================================
// PID TRACKING
// ======================================================

void trackTarget() {

    float errorPan  = (float)(CENTER_X - camX);
    float errorTilt = (float)(CENTER_Y - camY);

    // Integral with anti-windup
    integralPan  = constrain(integralPan  + errorPan,  -INTEGRAL_LIMIT, INTEGRAL_LIMIT);
    integralTilt = constrain(integralTilt + errorTilt, -INTEGRAL_LIMIT, INTEGRAL_LIMIT);

    // Derivative
    float dPan  = errorPan  - prevErrorPan;
    float dTilt = errorTilt - prevErrorTilt;

    // PID output
    float outPan  = kp_pan  * errorPan  + ki_pan  * integralPan  + kd_pan  * dPan;
    float outTilt = kp_tilt * errorTilt + ki_tilt * integralTilt + kd_tilt * dTilt;

    // Accumulate positions
    targetPan  += (long)outPan;
    targetTilt += (long)outTilt;

    // Hard limits
    targetPan  = constrain(targetPan,  -PAN_LIMIT,  PAN_LIMIT);
    targetTilt = constrain(targetTilt, -TILT_LIMIT, TILT_LIMIT);

    panStepper.moveTo(targetPan);
    tiltStepper.moveTo(targetTilt);

    prevErrorPan  = errorPan;
    prevErrorTilt = errorTilt;
}

// ======================================================
// RESET PID STATE
// Called when target is lost so integral doesn't wind up
// while the turret sits idle.
// ======================================================

void resetPID() {
    prevErrorPan  = 0;
    prevErrorTilt = 0;
    integralPan   = 0;
    integralTilt  = 0;
}

// ======================================================
// AUTO FIRE — non-blocking
// ======================================================

void autoFire() {

    if (firing) return;   // pulse already in progress

    const int TOLERANCE_X = 25;
    const int TOLERANCE_Y = 25;

    bool centeredX    = abs(camX - CENTER_X) < TOLERANCE_X;
    bool centeredY    = abs(camY - CENTER_Y) < TOLERANCE_Y;
    bool validRange   = distanceM > 0.5 && distanceM < 5.0;
    bool cooldownDone = (millis() - lastFireTime) > FIRE_COOLDOWN_MS;

    if (centeredX && centeredY && validRange && cooldownDone) {
        Serial.println("FIRE!");
        digitalWrite(FIRE_PIN, HIGH);
        firing        = true;
        fireStartTime = millis();
        lastFireTime  = millis();
    }
}

// ======================================================
// FIRE PULSE HANDLER — call every loop()
// Turns off fire pin after FIRE_PULSE_MS without blocking.
// ======================================================

void handleFirePulse() {
    if (firing && (millis() - fireStartTime >= FIRE_PULSE_MS)) {
        digitalWrite(FIRE_PIN, LOW);
        firing = false;
    }
}
