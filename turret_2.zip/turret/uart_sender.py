"""
Non-blocking UART sender.
Queues messages and sends them from a background thread so
the main vision loop never stalls waiting for serial I/O.
"""

import queue
import threading
import time

try:
    import serial
    SERIAL_AVAILABLE = True
except ImportError:
    SERIAL_AVAILABLE = False
    print("[UART] pyserial not found — running in MOCK mode.")


class UartSender:

    # Only keep the latest coordinate — drop stale ones
    QUEUE_MAX = 1

    def __init__(self, port: str = "/dev/serial0", baudrate: int = 115200):
        self._queue   = queue.Queue(maxsize=self.QUEUE_MAX)
        self._running = False
        self._thread  = None

        if SERIAL_AVAILABLE:
            try:
                self._ser = serial.Serial(port, baudrate, timeout=1)
                print(f"[UART] Connected on {port} @ {baudrate} baud.")
            except serial.SerialException as e:
                print(f"[UART] Could not open {port}: {e} — MOCK mode.")
                self._ser = None
        else:
            self._ser = None

    # ------------------------------------------------------------------
    def start(self):
        self._running = True
        self._thread = threading.Thread(
            target=self._send_loop,
            daemon=True
        )
        self._thread.start()

    # ------------------------------------------------------------------
    def stop(self):
        self._running = False
        if self._ser:
            self._ser.close()

    # ------------------------------------------------------------------
    def send(self, x: int, y: int, distance: float):
        """
        Enqueue a coordinate packet.
        If the queue is full (previous packet not yet sent), drop it —
        the ESP32 always wants the freshest data.
        """
        msg = f"{x},{y},{distance:.2f}\n"
        try:
            # Non-blocking put: raises Full if queue is at capacity
            self._queue.put_nowait(msg)
        except queue.Full:
            # Discard old, replace with latest
            try:
                self._queue.get_nowait()
            except queue.Empty:
                pass
            self._queue.put_nowait(msg)

    # ------------------------------------------------------------------
    def send_lost(self):
        """Notify ESP32 that the target has been lost."""
        msg = "L:\n"
        try:
            self._queue.put_nowait(msg)
        except queue.Full:
            pass

    # ------------------------------------------------------------------
    def _send_loop(self):
        while self._running:
            try:
                msg = self._queue.get(timeout=0.1)
                if self._ser and self._ser.is_open:
                    self._ser.write(msg.encode())
                else:
                    print(f"[UART MOCK] → {msg.strip()}")
            except queue.Empty:
                continue
            except Exception as e:
                print(f"[UART] Send error: {e}")
                time.sleep(0.1)
