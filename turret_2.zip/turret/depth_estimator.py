"""
Stereo depth estimation using StereoSGBM + WLS filter.
Given a rectified left/right pair, produces a depth map and
extracts the depth at a specific pixel location.
"""

import cv2
import numpy as np


class DepthEstimator:

    def __init__(self, focal_len: float, baseline: float):
        """
        focal_len : camera focal length in pixels
        baseline  : stereo baseline in metres
        """
        self.focal_len = focal_len
        self.baseline  = baseline

        # ── StereoSGBM parameters ─────────────────────────────────────
        min_disp   = 0
        num_disp   = 64      # must be divisible by 16
        block_size = 5

        self.left_matcher = cv2.StereoSGBM_create(
            minDisparity     = min_disp,
            numDisparities   = num_disp,
            blockSize        = block_size,
            P1               = 8  * 3 * block_size ** 2,
            P2               = 32 * 3 * block_size ** 2,
            disp12MaxDiff    = 1,
            uniquenessRatio  = 10,
            speckleWindowSize= 100,
            speckleRange     = 32,
            preFilterCap     = 63,
            mode             = cv2.STEREO_SGBM_MODE_SGBM_3WAY,
        )

        # WLS filter for smoother edges
        self.right_matcher = cv2.ximgproc.createRightMatcher(
            self.left_matcher
        )
        self.wls = cv2.ximgproc.createDisparityWLSFilter(
            matcher_left=self.left_matcher
        )
        self.wls.setLambda(8000)
        self.wls.setSigmaColor(1.5)

        self._disp_map = None

    # ------------------------------------------------------------------
    def compute(self, left: np.ndarray, right: np.ndarray):
        """
        Computes filtered disparity map from a rectified stereo pair.
        Stores result internally; call depth_at() to query a pixel.
        """
        gray_l = cv2.cvtColor(left,  cv2.COLOR_BGR2GRAY)
        gray_r = cv2.cvtColor(right, cv2.COLOR_BGR2GRAY)

        disp_l = self.left_matcher.compute(gray_l, gray_r)
        disp_r = self.right_matcher.compute(gray_r, gray_l)

        filtered = self.wls.filter(disp_l, gray_l, None, disp_r)

        # Convert from fixed-point (scale=16) to float pixels
        self._disp_map = filtered.astype(np.float32) / 16.0

        return self._disp_map

    # ------------------------------------------------------------------
    def depth_at(self, cx: int, cy: int, patch: int = 5) -> float:
        """
        Returns depth in metres at pixel (cx, cy).
        Averages over a (patch x patch) window to reduce noise.
        Returns 0.0 if disparity is invalid.
        """
        if self._disp_map is None:
            return 0.0

        h, w = self._disp_map.shape
        x0 = max(cx - patch, 0)
        x1 = min(cx + patch, w)
        y0 = max(cy - patch, 0)
        y1 = min(cy + patch, h)

        region = self._disp_map[y0:y1, x0:x1]
        valid  = region[region > 1.0]          # discard zero/negative disp

        if valid.size == 0:
            return 0.0

        disp_mean = float(np.median(valid))

        # Z = f * B / d
        return (self.focal_len * self.baseline) / disp_mean

    # ------------------------------------------------------------------
    def colormap(self) -> np.ndarray:
        """Returns a colour-mapped disparity image for visualisation."""
        if self._disp_map is None:
            return np.zeros((480, 640, 3), dtype=np.uint8)

        norm = cv2.normalize(
            self._disp_map, None, 0, 255,
            cv2.NORM_MINMAX, cv2.CV_8U
        )
        return cv2.applyColorMap(norm, cv2.COLORMAP_JET)
