"""
WiFi UDP sender — replaces uart_sender.py for wireless operation.
Sends coordinate packets to ESP32 over UDP on the local network.

Protocol (same as UART):
  Target  →  "320,240,2.00\n"
  Lost    →  "L:\n"
"""

import queue
import socket
import threading
import time


class WifiSender:

    QUEUE_MAX = 1   # always send latest, drop stale

    def __init__(self, esp32_ip: str, port: int = 5005):
        """
        esp32_ip : IP address of the ESP32 on your WiFi network
        port     : UDP port (must match ESP32 code)
        """
        self.esp32_ip = esp32_ip
        self.port     = port

        self._queue   = queue.Queue(maxsize=self.QUEUE_MAX)
        self._running = False
        self._thread  = None

        self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 1024)

        print(f"[WiFi] UDP sender ready → {esp32_ip}:{port}")

    # ------------------------------------------------------------------
    def start(self):
        self._running = True
        self._thread = threading.Thread(
            target=self._send_loop,
            daemon=True
        )
        self._thread.start()

    # ------------------------------------------------------------------
    def stop(self):
        self._running = False
        self._sock.close()

    # ------------------------------------------------------------------
    def send(self, x: int, y: int, distance: float):
        msg = f"{x},{y},{distance:.2f}\n"
        self._enqueue(msg)

    def send_lost(self):
        self._enqueue("L:\n")

    # ------------------------------------------------------------------
    def _enqueue(self, msg: str):
        try:
            self._queue.put_nowait(msg)
        except queue.Full:
            try:
                self._queue.get_nowait()
            except queue.Empty:
                pass
            self._queue.put_nowait(msg)

    # ------------------------------------------------------------------
    def _send_loop(self):
        while self._running:
            try:
                msg = self._queue.get(timeout=0.1)
                self._sock.sendto(
                    msg.encode(),
                    (self.esp32_ip, self.port)
                )
            except queue.Empty:
                continue
            except Exception as e:
                print(f"[WiFi] Send error: {e}")
                time.sleep(0.1)
