"""
Adaptive image enhancement for all lighting conditions.

Detects the scene type from luminance statistics and applies the
appropriate correction chain:

  DARK        → denoise + aggressive CLAHE + gamma boost
  NORMAL      → light CLAHE only
  BRIGHT      → tone-map + CLAHE
  BACKLIT     → local tone-map + CLAHE (handles dark subject on bright BG)
  HIGH_CONTRAST → bilateral filter + CLAHE

For stereo pairs both frames are enhanced identically using the
parameters derived from the LEFT frame, so L/R contrast stays matched.
"""

import cv2
import numpy as np
from dataclasses import dataclass
from enum import Enum, auto


class LightCondition(Enum):
    DARK           = auto()   # mean < 50
    DIM            = auto()   # mean 50–80
    NORMAL         = auto()   # mean 80–180
    BRIGHT         = auto()   # mean > 180
    BACKLIT        = auto()   # low mean but high std (bright BG, dark FG)
    HIGH_CONTRAST  = auto()   # std > 70


@dataclass
class SceneStats:
    mean: float
    std: float
    condition: LightCondition


class ImageEnhancer:

    # CLAHE tile grid — smaller = more local correction
    _CLAHE_TILE   = (8, 8)

    # Smoothing for the condition time-average (prevents mode flicker)
    _EMA_ALPHA    = 0.15

    def __init__(self):
        # Separate CLAHE instances for different intensities
        self._clahe_light      = cv2.createCLAHE(clipLimit=2.0,  tileGridSize=self._CLAHE_TILE)
        self._clahe_medium     = cv2.createCLAHE(clipLimit=4.0,  tileGridSize=self._CLAHE_TILE)
        self._clahe_aggressive = cv2.createCLAHE(clipLimit=8.0,  tileGridSize=self._CLAHE_TILE)

        self._ema_mean = None   # smoothed brightness over time
        self._ema_std  = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def enhance(self, frame: np.ndarray) -> np.ndarray:
        """Enhance a single frame. Detects scene and applies correction."""
        stats = self._analyze(frame)
        return self._apply(frame, stats)

    def enhance_stereo(
        self,
        left: np.ndarray,
        right: np.ndarray,
    ) -> tuple[np.ndarray, np.ndarray]:
        """
        Enhance a stereo pair.
        Parameters are derived from the LEFT frame only, then applied
        identically to both so L/R contrast stays matched.
        """
        stats = self._analyze(left)
        return self._apply(left, stats), self._apply(right, stats)

    def scene_condition(self, frame: np.ndarray) -> LightCondition:
        return self._analyze(frame).condition

    # ------------------------------------------------------------------
    # Scene analysis
    # ------------------------------------------------------------------

    def _analyze(self, frame: np.ndarray) -> SceneStats:
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        mean = float(np.mean(gray))
        std  = float(np.std(gray))

        # Exponential moving average — smooths rapid lighting changes
        if self._ema_mean is None:
            self._ema_mean, self._ema_std = mean, std
        else:
            a = self._EMA_ALPHA
            self._ema_mean = a * mean + (1 - a) * self._ema_mean
            self._ema_std  = a * std  + (1 - a) * self._ema_std

        m, s = self._ema_mean, self._ema_std

        if s > 70:
            condition = LightCondition.HIGH_CONTRAST
        elif m < 30 and s < 20:
            condition = LightCondition.DARK          # very dark, little contrast
        elif m < 50:
            condition = LightCondition.DARK
        elif m < 80:
            condition = LightCondition.DIM
        elif m > 200:
            condition = LightCondition.BRIGHT
        elif m < 100 and s > 50:
            condition = LightCondition.BACKLIT       # dark subject, bright BG
        else:
            condition = LightCondition.NORMAL

        return SceneStats(mean=m, std=s, condition=condition)

    # ------------------------------------------------------------------
    # Enhancement chains
    # ------------------------------------------------------------------

    def _apply(self, frame: np.ndarray, stats: SceneStats) -> np.ndarray:
        c = stats.condition

        if c == LightCondition.DARK:
            return self._enhance_dark(frame)
        elif c == LightCondition.DIM:
            return self._enhance_dim(frame)
        elif c == LightCondition.BRIGHT:
            return self._enhance_bright(frame)
        elif c == LightCondition.BACKLIT:
            return self._enhance_backlit(frame)
        elif c == LightCondition.HIGH_CONTRAST:
            return self._enhance_high_contrast(frame)
        else:
            return self._enhance_normal(frame)

    # ── Dark ──────────────────────────────────────────────────────────
    def _enhance_dark(self, frame: np.ndarray) -> np.ndarray:
        # 1. Denoise first (CLAHE amplifies noise)
        denoised = cv2.fastNlMeansDenoisingColored(frame, None, 7, 7, 7, 21)

        # 2. Gamma boost (gamma < 1 brightens)
        boosted = self._gamma(denoised, gamma=0.5)

        # 3. Aggressive CLAHE in LAB colour space
        return self._clahe_lab(boosted, self._clahe_aggressive)

    # ── Dim ───────────────────────────────────────────────────────────
    def _enhance_dim(self, frame: np.ndarray) -> np.ndarray:
        brightened = self._gamma(frame, gamma=0.7)
        return self._clahe_lab(brightened, self._clahe_medium)

    # ── Normal ────────────────────────────────────────────────────────
    def _enhance_normal(self, frame: np.ndarray) -> np.ndarray:
        return self._clahe_lab(frame, self._clahe_light)

    # ── Bright ───────────────────────────────────────────────────────
    def _enhance_bright(self, frame: np.ndarray) -> np.ndarray:
        # Tone-map to recover blown-out highlights, then CLAHE
        tone_mapped = self._reinhard_tone_map(frame)
        return self._clahe_lab(tone_mapped, self._clahe_medium)

    # ── Backlit ───────────────────────────────────────────────────────
    def _enhance_backlit(self, frame: np.ndarray) -> np.ndarray:
        # Local tone-map: brightens shadows without blowing highlights
        lab = cv2.cvtColor(frame, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)

        # CLAHE on L channel recovers shadow detail
        l_eq = self._clahe_aggressive.apply(l)

        # Subtract background: morphological top-hat
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (31, 31))
        tophat = cv2.morphologyEx(l_eq, cv2.MORPH_TOPHAT, kernel)
        l_final = cv2.add(l_eq, tophat)

        merged = cv2.merge([l_final, a, b])
        return cv2.cvtColor(merged, cv2.COLOR_LAB2BGR)

    # ── High contrast ─────────────────────────────────────────────────
    def _enhance_high_contrast(self, frame: np.ndarray) -> np.ndarray:
        # Bilateral preserves edges while smoothing extreme contrast zones
        smooth = cv2.bilateralFilter(frame, d=9, sigmaColor=75, sigmaSpace=75)
        return self._clahe_lab(smooth, self._clahe_medium)

    # ------------------------------------------------------------------
    # Primitive operations
    # ------------------------------------------------------------------

    @staticmethod
    def _gamma(frame: np.ndarray, gamma: float) -> np.ndarray:
        """Fast LUT-based gamma correction."""
        inv_gamma = 1.0 / gamma
        table = np.array([
            ((i / 255.0) ** inv_gamma) * 255
            for i in range(256)
        ], dtype=np.uint8)
        return cv2.LUT(frame, table)

    @staticmethod
    def _clahe_lab(frame: np.ndarray, clahe) -> np.ndarray:
        """Apply CLAHE to the L channel of LAB — preserves colour."""
        lab = cv2.cvtColor(frame, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        l_eq = clahe.apply(l)
        merged = cv2.merge([l_eq, a, b])
        return cv2.cvtColor(merged, cv2.COLOR_LAB2BGR)

    @staticmethod
    def _reinhard_tone_map(frame: np.ndarray) -> np.ndarray:
        """
        Simple Reinhard global tone mapping.
        Compresses bright values while preserving shadow detail.
        """
        img_f = frame.astype(np.float32) / 255.0
        mapped = img_f / (1.0 + img_f)   # Reinhard operator
        return (mapped * 255).clip(0, 255).astype(np.uint8)
