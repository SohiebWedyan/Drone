"""
Sensor fusion  +  Kalman filter  +  target state management.

Fusion:
  fused_dist = w_stereo * stereo_dist + w_lidar * lidar_dist
  Weights adapt based on which sensor has a valid reading.

Kalman filter (OpenCV):
  State  : [x, y, vx, vy]
  Measure: [x, y]
  Predicts next position to smooth jitter and handle missed frames.
"""

import cv2
import numpy as np
import time


class FusionTracker:

    # Weight for each sensor when both are valid
    W_STEREO = 0.4
    W_LIDAR  = 0.6

    # Kalman noise tuning
    PROCESS_NOISE     = 1e-2
    MEASUREMENT_NOISE = 1e-1

    # Seconds without a detection before declaring target lost
    LOST_TIMEOUT = 0.5

    def __init__(self):
        self._kf = self._build_kalman()
        self._last_seen   = 0.0
        self._initialized = False
        self.predicted_x  = 0
        self.predicted_y  = 0

    # ------------------------------------------------------------------
    def _build_kalman(self) -> cv2.KalmanFilter:
        kf = cv2.KalmanFilter(4, 2)   # 4 states, 2 measurements

        # State transition:  x' = x + vx*dt  (dt≈1, absorbed into noise)
        kf.transitionMatrix = np.array([
            [1, 0, 1, 0],
            [0, 1, 0, 1],
            [0, 0, 1, 0],
            [0, 0, 0, 1],
        ], dtype=np.float32)

        # Measurement maps [x, y] from state
        kf.measurementMatrix = np.array([
            [1, 0, 0, 0],
            [0, 1, 0, 0],
        ], dtype=np.float32)

        kf.processNoiseCov = (
            np.eye(4, dtype=np.float32) * self.PROCESS_NOISE
        )
        kf.measurementNoiseCov = (
            np.eye(2, dtype=np.float32) * self.MEASUREMENT_NOISE
        )
        kf.errorCovPost = np.eye(4, dtype=np.float32)

        return kf

    # ------------------------------------------------------------------
    def fuse_distance(
        self,
        stereo_dist: float,
        lidar_dist: float
    ) -> float:
        """
        Combines stereo and LiDAR distances.
        Falls back to whichever sensor has a valid reading.
        """
        stereo_valid = stereo_dist > 0.1
        lidar_valid  = lidar_dist  > 0.1

        if stereo_valid and lidar_valid:
            return self.W_STEREO * stereo_dist + self.W_LIDAR * lidar_dist

        if stereo_valid:
            return stereo_dist

        if lidar_valid:
            return lidar_dist

        return 0.0

    # ------------------------------------------------------------------
    def update(
        self,
        cx: int,
        cy: int,
        stereo_dist: float,
        lidar_dist: float,
    ) -> tuple[int, int, float]:
        """
        Feed a new detection into the Kalman filter.

        Returns (smooth_x, smooth_y, fused_distance).
        """
        self._last_seen = time.time()

        measurement = np.array([[np.float32(cx)],
                                 [np.float32(cy)]])

        if not self._initialized:
            # Seed the filter at the first detection
            self._kf.statePre = np.array(
                [[np.float32(cx)],
                 [np.float32(cy)],
                 [0.0],
                 [0.0]],
                dtype=np.float32
            )
            self._initialized = True

        self._kf.correct(measurement)
        prediction = self._kf.predict()

        self.predicted_x = int(prediction[0])
        self.predicted_y = int(prediction[1])

        fused = self.fuse_distance(stereo_dist, lidar_dist)

        return self.predicted_x, self.predicted_y, fused

    # ------------------------------------------------------------------
    def predict_only(self) -> tuple[int, int]:
        """
        Called when no detection this frame — advances the filter
        using motion model alone.
        """
        if not self._initialized:
            return self.predicted_x, self.predicted_y

        prediction = self._kf.predict()
        self.predicted_x = int(prediction[0])
        self.predicted_y = int(prediction[1])

        return self.predicted_x, self.predicted_y

    # ------------------------------------------------------------------
    @property
    def target_lost(self) -> bool:
        if not self._initialized:
            return True
        return (time.time() - self._last_seen) > self.LOST_TIMEOUT

    # ------------------------------------------------------------------
    def reset(self):
        self._kf = self._build_kalman()
        self._initialized = False
        self._last_seen   = 0.0
