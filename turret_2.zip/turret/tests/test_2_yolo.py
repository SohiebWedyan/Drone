"""
TEST 2 — YOLO Detection
Checks: model loads, detects objects, prints results.
Run: python test_2_yolo.py
"""

import cv2
import time
from ultralytics import YOLO

CAM_INDEX  = 2       # use your working camera index
YOLO_MODEL = "yolov8n.pt"
TEST_SECS  = 30      # how long to run the test

print("=" * 40)
print("  TEST 2 — YOLO Detection")
print("=" * 40)

# ── Load model ────────────────────────────────────────────────────────
print("\n[1] Loading YOLO model ...")
t0 = time.time()
model = YOLO(YOLO_MODEL)
print(f"    PASS — Model loaded in {time.time()-t0:.1f}s")

# ── Open camera ───────────────────────────────────────────────────────
print(f"\n[2] Opening camera {CAM_INDEX} ...")
cap = cv2.VideoCapture(CAM_INDEX)
cap.set(cv2.CAP_PROP_FRAME_WIDTH,  640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

if not cap.isOpened():
    print("    FAIL — Camera not found")
    exit(1)
print("    PASS — Camera open")

# ── Detection loop ────────────────────────────────────────────────────
print(f"\n[3] Running detection for {TEST_SECS}s — point camera at any object ...\n")

total_frames    = 0
detected_frames = 0
start = time.time()

while time.time() - start < TEST_SECS:
    ok, frame = cap.read()
    if not ok:
        continue

    results = model(frame, verbose=False, conf=0.4)
    total_frames += 1

    boxes = results[0].boxes
    if boxes and len(boxes) > 0:
        detected_frames += 1
        for box in boxes:
            cls_id = int(box.cls[0])
            conf   = float(box.conf[0])
            label  = model.names[cls_id]
            x1,y1,x2,y2 = map(int, box.xyxy[0])
            cx = (x1 + x2) // 2
            cy = (y1 + y2) // 2
            print(f"  DETECTED: {label:15s}  conf={conf:.2f}  center=({cx},{cy})")

            # Draw on frame
            cv2.rectangle(frame, (x1,y1), (x2,y2), (0,255,0), 2)
            cv2.putText(frame, f"{label} {conf:.2f}",
                        (x1, y1-8), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0,255,0), 1)

    elapsed = time.time() - start
    fps = total_frames / max(elapsed, 0.001)
    cv2.putText(frame, f"FPS:{fps:.1f}  Frames:{total_frames}  Det:{detected_frames}",
                (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (200,200,200), 1)

    cv2.imshow("YOLO Test", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()

# ── Summary ───────────────────────────────────────────────────────────
fps = total_frames / max(time.time() - start, 0.001)

print("\n" + "=" * 40)
print(f"  Total frames   : {total_frames}")
print(f"  Average FPS    : {fps:.1f}")
print(f"  Detected frames: {detected_frames}")
print(f"  Detection rate : {100*detected_frames/max(total_frames,1):.1f}%")

if fps >= 5:
    print("\n  PASS ✓ — YOLO running OK")
    print("  Proceed to test_3_depth.py")
else:
    print("\n  WARN — FPS is low (normal on Pi without GPU acceleration)")
print("=" * 40)
