"""
TEST 5 — WiFi UDP Communication
Run AFTER uploading turret_esp32_wifi.ino to ESP32.
Open ESP32 Serial Monitor to see received packets.

Run: python test_5_wifi.py --ip 192.168.1.XX
"""

import argparse
import socket
import time

parser = argparse.ArgumentParser()
parser.add_argument("--ip",   required=True, help="ESP32 IP address")
parser.add_argument("--port", type=int, default=5005)
args = parser.parse_args()

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

def send(msg):
    sock.sendto(msg.encode(), (args.ip, args.port))
    print(f"  Sent → {msg.strip()}")
    time.sleep(0.3)

print("=" * 40)
print(f"  TEST 5 — WiFi UDP to ESP32")
print(f"  Target: {args.ip}:{args.port}")
print("=" * 40)

print("\n[1] Sending centre coordinates (FIRE expected) ...")
for _ in range(5):
    send("320,240,2.00\n")

print("\n[2] Sending off-centre coordinates ...")
for x, y in [(100,100), (500,400), (50,300)]:
    send(f"{x},{y},2.00\n")

print("\n[3] Sending target-lost signal ...")
send("L:\n")

print("\n[4] Sending rapid packets (latency test) ...")
start = time.time()
for i in range(50):
    send(f"320,240,{2.0 + i*0.01:.2f}\n")
elapsed = time.time() - start
print(f"\n  50 packets sent in {elapsed:.2f}s ({50/elapsed:.0f} packets/sec)")

sock.close()

print("\n" + "=" * 40)
print("  Check ESP32 Serial Monitor for received packets.")
print("  If you see X:320 Y:240 D:2.00 → PASS ✓")
print("=" * 40)
