"""
TEST 5 — UART Communication (Raspberry Pi → ESP32)
Checks: port opens, data sends, ESP32 echoes back.

Run FIRST on ESP32 — open Serial Monitor at 115200 baud.
Then run: python test_5_uart.py

You should see on ESP32 Serial Monitor:
  X:320 Y:240 D:2.00
  FIRE!  (when centred)
"""

import serial
import time
import sys

UART_PORT = "/dev/serial0"   # GPIO UART
# UART_PORT = "/dev/ttyUSB0"  # uncomment if using USB cable
BAUDRATE  = 115200

print("=" * 40)
print("  TEST 5 — UART to ESP32")
print("=" * 40)

# ── Open port ─────────────────────────────────────────────────────────
try:
    ser = serial.Serial(UART_PORT, BAUDRATE, timeout=1)
    print(f"  PASS — Port opened: {UART_PORT}\n")
except Exception as e:
    print(f"  FAIL — Cannot open {UART_PORT}: {e}")
    print("\n  Checklist:")
    print("  1. sudo raspi-config → Interface Options → Serial → enabled")
    print("  2. Reboot the Pi")
    print("  3. Check wiring: Pi GPIO14(TX) → ESP32 GPIO16(RX)")
    sys.exit(1)

# ── Test 1: Send target packets ───────────────────────────────────────
print("  [Test 1] Sending 10 coordinate packets ...")
for i in range(10):
    x    = 320
    y    = 240
    dist = 2.00
    msg  = f"{x},{y},{dist:.2f}\n"
    ser.write(msg.encode())
    print(f"    Sent: {msg.strip()}")
    time.sleep(0.2)

# ── Test 2: Send off-centre packets (should NOT fire) ─────────────────
print("\n  [Test 2] Sending off-centre packets (no fire expected) ...")
for x, y in [(100, 100), (500, 400), (50, 300)]:
    msg = f"{x},{y},2.00\n"
    ser.write(msg.encode())
    print(f"    Sent: {msg.strip()}")
    time.sleep(0.3)

# ── Test 3: Send centred packet (should trigger FIRE) ─────────────────
print("\n  [Test 3] Sending centred packet within range (FIRE expected) ...")
msg = "320,240,2.00\n"
ser.write(msg.encode())
print(f"    Sent: {msg.strip()}")
time.sleep(0.5)

# ── Test 4: Send lost-target signal ───────────────────────────────────
print("\n  [Test 4] Sending target-lost signal ...")
ser.write(b"L:\n")
print("    Sent: L:")
time.sleep(0.3)

# ── Read any response from ESP32 ──────────────────────────────────────
print("\n  [Reading ESP32 response for 3s ...]")
start = time.time()
received = []
while time.time() - start < 3:
    if ser.in_waiting:
        line = ser.readline().decode(errors='ignore').strip()
        if line:
            received.append(line)
            print(f"    ESP32 → {line}")

ser.close()

# ── Summary ───────────────────────────────────────────────────────────
print("\n" + "=" * 40)
if received:
    print(f"  PASS ✓ — ESP32 responded ({len(received)} lines)")
    print("  UART communication working correctly")
else:
    print("  PARTIAL — Data sent successfully")
    print("  No response received from ESP32")
    print("  (Normal if ESP32 Serial Monitor is not open)")
    print("  Check ESP32 Serial Monitor for received packets")
print("=" * 40)
