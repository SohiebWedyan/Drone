"""
TEST 1 — Camera
Checks: cameras open, frames readable, resolution correct.
Run: python test_1_camera.py
"""

import cv2
import sys

CAM_LEFT  = 0   # change if needed
CAM_RIGHT = 2   # change if needed
WIDTH     = 640
HEIGHT    = 480

def test_camera(index, label):
    print(f"\n[{label}] Testing camera index {index} ...")

    cap = cv2.VideoCapture(index)
    if not cap.isOpened():
        print(f"  FAIL — Could not open camera {index}")
        return False

    cap.set(cv2.CAP_PROP_FRAME_WIDTH,  WIDTH)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, HEIGHT)

    ok, frame = cap.read()
    if not ok or frame is None:
        print(f"  FAIL — Camera opened but could not read frame")
        cap.release()
        return False

    h, w = frame.shape[:2]
    print(f"  PASS — Frame received: {w}x{h}")

    # Save a snapshot
    path = f"/home/drone/Desktop/turret/tests/snapshot_{label}.jpg"
    cv2.imwrite(path, frame)
    print(f"  Snapshot saved → {path}")

    # Live preview for 5 seconds
    print(f"  Showing live feed for 5 seconds (press Q to quit early)...")
    import time
    start = time.time()
    while time.time() - start < 5:
        ok, frame = cap.read()
        if not ok:
            break
        cv2.putText(frame, f"Camera {index} — {label}",
                    (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,255,0), 2)
        cv2.imshow(f"Camera {index}", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
    return True


if __name__ == "__main__":
    print("=" * 40)
    print("  TEST 1 — Camera")
    print("=" * 40)

    left_ok  = test_camera(CAM_LEFT,  "LEFT")
    right_ok = test_camera(CAM_RIGHT, "RIGHT")

    print("\n" + "=" * 40)
    print(f"  LEFT  camera: {'PASS ✓' if left_ok  else 'FAIL ✗'}")
    print(f"  RIGHT camera: {'PASS ✓' if right_ok else 'FAIL ✗'}")
    print("=" * 40)

    if left_ok and right_ok:
        print("\n  All cameras OK — proceed to test_2_yolo.py")
    else:
        print("\n  Fix camera indices before continuing.")
        print("  Run: python3 -c \"import cv2; [print(i, cv2.VideoCapture(i).read()[0]) for i in range(6)]\"")
