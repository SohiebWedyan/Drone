"""
TEST 3 — Stereo Depth Estimation
Checks: both cameras readable, disparity map generated, depth values reasonable.
Run: python test_3_depth.py
"""

import cv2
import numpy as np
import sys
import time

CAM_LEFT   = 2
CAM_RIGHT  = 0
FOCAL_LEN  = 600.0   # pixels (replace after calibration)
BASELINE   = 0.06    # metres

print("=" * 40)
print("  TEST 3 — Stereo Depth")
print("=" * 40)

# ── Open cameras ──────────────────────────────────────────────────────
cap_l = cv2.VideoCapture(CAM_LEFT)
cap_r = cv2.VideoCapture(CAM_RIGHT)

for cap in (cap_l, cap_r):
    cap.set(cv2.CAP_PROP_FRAME_WIDTH,  640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

if not cap_l.isOpened() or not cap_r.isOpened():
    print("  FAIL — Could not open both cameras")
    sys.exit(1)
print("  PASS — Both cameras open\n")

# ── Build stereo matcher ──────────────────────────────────────────────
block = 5
left_matcher = cv2.StereoSGBM_create(
    minDisparity    = 0,
    numDisparities  = 64,
    blockSize       = block,
    P1              = 8  * 3 * block**2,
    P2              = 32 * 3 * block**2,
    disp12MaxDiff   = 1,
    uniquenessRatio = 10,
    speckleWindowSize = 100,
    speckleRange    = 32,
    mode            = cv2.STEREO_SGBM_MODE_SGBM_3WAY,
)
right_matcher = cv2.ximgproc.createRightMatcher(left_matcher)
wls = cv2.ximgproc.createDisparityWLSFilter(left_matcher)
wls.setLambda(8000)
wls.setSigmaColor(1.5)

print("Running stereo depth test — hold an object ~50cm in front of both cameras.")
print("Press Q to quit.\n")

frame_count = 0
start = time.time()

while True:
    ok_l, left  = cap_l.read()
    ok_r, right = cap_r.read()
    if not ok_l or not ok_r:
        print("  Frame read failed")
        continue

    gray_l = cv2.cvtColor(left,  cv2.COLOR_BGR2GRAY)
    gray_r = cv2.cvtColor(right, cv2.COLOR_BGR2GRAY)

    disp_l = left_matcher.compute(gray_l, gray_r)
    disp_r = right_matcher.compute(gray_r, gray_l)
    disp_f = wls.filter(disp_l, gray_l, None, disp_r).astype(np.float32) / 16.0

    # Depth at centre
    cx, cy = 320, 240
    patch  = disp_f[cy-5:cy+5, cx-5:cx+5]
    valid  = patch[patch > 1.0]
    if valid.size > 0:
        depth = (FOCAL_LEN * BASELINE) / float(np.median(valid))
        depth_str = f"{depth:.2f} m"
    else:
        depth_str = "N/A"

    # Colourmap
    norm = cv2.normalize(disp_f, None, 0, 255, cv2.NORM_MINMAX, cv2.CV_8U)
    disp_colour = cv2.applyColorMap(norm, cv2.COLORMAP_JET)
    cv2.drawMarker(disp_colour, (cx,cy), (255,255,255), cv2.MARKER_CROSS, 20, 2)

    frame_count += 1
    fps = frame_count / max(time.time()-start, 0.001)

    cv2.putText(disp_colour, f"Centre depth: {depth_str}",
                (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255,255,255), 2)
    cv2.putText(disp_colour, f"FPS: {fps:.1f}",
                (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (200,200,200), 1)

    print(f"  Frame {frame_count:4d} | FPS {fps:.1f} | Centre depth: {depth_str}")

    cv2.imshow("Left Camera",  left)
    cv2.imshow("Disparity Map", disp_colour)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap_l.release()
cap_r.release()
cv2.destroyAllWindows()

print("\n" + "=" * 40)
print(f"  Frames processed: {frame_count}")
print(f"  Average FPS     : {fps:.1f}")
print("  If depth values were reasonable → PASS ✓")
print("  If depth was N/A always → cameras may need calibration")
print("=" * 40)
