"""
TEST 4 — LiDAR
Checks: SDK binary runs, distance readings parsed, values reasonable.
Run: python test_4_lidar.py
"""

import re
import subprocess
import sys
import time

SDK_BINARY = "/home/drone/rplidar_sdk/output/Linux/Release/ultra_simple"
SDK_PORT   = "/dev/ttyUSB0"
SDK_BAUD   = "460800"
TEST_SECS  = 15

LINE_RE = re.compile(r"theta:\s*([\d.]+)\s*Dist:\s*([\d.]+)")

print("=" * 40)
print("  TEST 4 — LiDAR")
print("=" * 40)

# ── Check binary exists ───────────────────────────────────────────────
import os
if not os.path.exists(SDK_BINARY):
    # Try to find it
    import glob
    matches = glob.glob("/home/drone/rplidar_sdk/output/Linux/Release/*")
    print(f"  FAIL — Binary not found: {SDK_BINARY}")
    print(f"  Files in Release folder: {matches}")
    sys.exit(1)
print(f"  PASS — Binary found: {SDK_BINARY}")

# ── Check port ────────────────────────────────────────────────────────
if not os.path.exists(SDK_PORT):
    print(f"  FAIL — LiDAR port not found: {SDK_PORT}")
    print("  Check: ls /dev/ttyUSB*  or  ls /dev/ttyACM*")
    sys.exit(1)
print(f"  PASS — Port found: {SDK_PORT}\n")

# ── Start SDK process ─────────────────────────────────────────────────
print(f"  Starting LiDAR scan for {TEST_SECS}s ...")
print(f"  Rotate the LiDAR if readings show 0 distance.\n")

process = subprocess.Popen(
    [SDK_BINARY, "--channel", "--serial", SDK_PORT, SDK_BAUD],
    stdout=subprocess.PIPE,
    stderr=subprocess.STDOUT,
    text=True,
)

readings = 0
angles_seen = set()
start = time.time()

try:
    for line in process.stdout:
        if time.time() - start > TEST_SECS:
            break

        match = LINE_RE.search(line)
        if match:
            angle  = float(match.group(1))
            dist_m = float(match.group(2)) / 1000.0
            readings += 1
            angles_seen.add(int(angle))

            if readings <= 20 or readings % 100 == 0:
                print(f"  Reading {readings:5d} | angle={angle:6.1f}°  dist={dist_m:.3f} m")

finally:
    process.terminate()

# ── Summary ───────────────────────────────────────────────────────────
coverage = len(angles_seen)
rate     = readings / max(time.time()-start, 0.001)

print("\n" + "=" * 40)
print(f"  Total readings : {readings}")
print(f"  Reading rate   : {rate:.0f} readings/sec")
print(f"  Angle coverage : {coverage}° out of 360°")

if readings > 100 and coverage > 180:
    print("\n  PASS ✓ — LiDAR working correctly")
    print("  Proceed to test_5_uart.py")
elif readings > 0:
    print("\n  WARN — Some readings received but coverage is low")
    print("  Check LiDAR is spinning freely")
else:
    print("\n  FAIL ✗ — No readings received")
    print("  Check: LiDAR is powered and USB cable connected")
print("=" * 40)
