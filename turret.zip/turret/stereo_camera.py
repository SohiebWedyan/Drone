"""
Stereo camera capture and rectification.
Loads calibration data, opens both cameras, returns rectified frame pairs.
Includes adaptive exposure control for indoor/outdoor lighting.
"""

import cv2
import numpy as np


# Exposure target range (mean pixel brightness)
_TARGET_BRIGHTNESS_LOW  = 90
_TARGET_BRIGHTNESS_HIGH = 160

# Exposure value step per adjustment tick (V4L2 units, typically -13 to -1)
_EXPOSURE_STEP = 1


class StereoCamera:

    def __init__(
        self,
        cam_left_id: int = 0,
        cam_right_id: int = 1,
        width: int = 640,
        height: int = 480,
        calib_file: str = "stereo_calib.npz",
        auto_exposure: bool = True,
    ):
        self.width  = width
        self.height = height
        self._auto_exposure = auto_exposure
        self._exposure_val  = -6   # starting mid-range value

        self.cap_left  = cv2.VideoCapture(cam_left_id)
        self.cap_right = cv2.VideoCapture(cam_right_id)

        for cap in (self.cap_left, self.cap_right):
            cap.set(cv2.CAP_PROP_FRAME_WIDTH,  width)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
            cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

        self._set_exposure_mode()

        self.map_lx, self.map_ly = None, None
        self.map_rx, self.map_ry = None, None

        self._load_calibration(calib_file)

    # ------------------------------------------------------------------
    def _set_exposure_mode(self):
        """
        Switch cameras between auto and manual exposure.
        V4L2 property: 1 = manual, 3 = auto.
        """
        mode = 3 if self._auto_exposure else 1
        for cap in (self.cap_left, self.cap_right):
            cap.set(cv2.CAP_PROP_AUTO_EXPOSURE, mode)
        if not self._auto_exposure:
            self._apply_exposure()

    def _apply_exposure(self):
        val = max(-13, min(-1, self._exposure_val))
        for cap in (self.cap_left, self.cap_right):
            cap.set(cv2.CAP_PROP_EXPOSURE, val)

    def adjust_exposure(self, mean_brightness: float):
        """
        Call with the mean brightness of the current left frame.
        Nudges exposure up or down to keep brightness in the target range.
        Only active when auto_exposure=False.
        """
        if self._auto_exposure:
            return

        if mean_brightness < _TARGET_BRIGHTNESS_LOW:
            self._exposure_val += _EXPOSURE_STEP   # brighter
        elif mean_brightness > _TARGET_BRIGHTNESS_HIGH:
            self._exposure_val -= _EXPOSURE_STEP   # darker

        self._apply_exposure()

    def set_manual_exposure(self, value: int):
        """Directly set exposure value (-13 to -1). Disables auto mode."""
        self._auto_exposure = False
        self._exposure_val  = value
        self._set_exposure_mode()

    # ------------------------------------------------------------------
    def _load_calibration(self, path: str):
        try:
            data = np.load(path)

            R1 = data["R1"]
            R2 = data["R2"]
            P1 = data["P1"]
            P2 = data["P2"]

            self.Q          = data["Q"]           # disparity-to-depth matrix
            self.focal_len  = float(P1[0, 0])     # fx
            self.baseline   = float(-P2[0, 3] / P1[0, 0])  # metres

            size = (self.width, self.height)

            self.map_lx, self.map_ly = cv2.initUndistortRectifyMap(
                data["K1"], data["D1"], R1, P1, size, cv2.CV_16SC2
            )
            self.map_rx, self.map_ry = cv2.initUndistortRectifyMap(
                data["K2"], data["D2"], R2, P2, size, cv2.CV_16SC2
            )

            print("[StereoCamera] Calibration loaded.")

        except FileNotFoundError:
            # ── Fallback: uncalibrated placeholder values ──────────────
            print("[StereoCamera] WARNING: calib file not found — using defaults.")
            self.Q         = None
            self.focal_len = 600.0   # pixels  — replace after calibration
            self.baseline  = 0.06    # metres  — replace after calibration

    # ------------------------------------------------------------------
    def read(self):
        """
        Returns (left_rect, right_rect) or (None, None) on failure.
        Applies rectification if calibration was loaded.
        """
        ok_l, frame_l = self.cap_left.read()
        ok_r, frame_r = self.cap_right.read()

        if not ok_l or not ok_r:
            return None, None

        if self.map_lx is not None:
            frame_l = cv2.remap(frame_l, self.map_lx, self.map_ly, cv2.INTER_LINEAR)
            frame_r = cv2.remap(frame_r, self.map_rx, self.map_ry, cv2.INTER_LINEAR)

        return frame_l, frame_r

    # ------------------------------------------------------------------
    def release(self):
        self.cap_left.release()
        self.cap_right.release()
