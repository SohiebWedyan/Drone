"""
AI Stereo Vision + LiDAR Tracking Turret — Raspberry Pi main loop.

Pipeline:
  Stereo cameras → Adaptive enhancement → YOLO detection → Stereo depth
  → LiDAR distance → Sensor fusion → Kalman filter → UART → ESP32

Usage:
  python main.py
  python main.py --port /dev/ttyUSB0    # if using USB instead of GPIO
  python main.py --no-display           # headless / SSH mode
  python main.py --manual-exposure      # disable camera auto-exposure
"""

import argparse
import time
import cv2
import numpy as np
from ultralytics import YOLO

from stereo_camera   import StereoCamera
from depth_estimator import DepthEstimator
from lidar_reader    import LidarReader
from fusion_tracker  import FusionTracker
from uart_sender     import UartSender
from image_enhancer  import ImageEnhancer, LightCondition

# ──────────────────────────────────────────────────────────────────────
# Configuration
# ──────────────────────────────────────────────────────────────────────

FRAME_W = 640
FRAME_H = 480
CENTER_X = FRAME_W // 2
CENTER_Y = FRAME_H // 2

# YOLO — change to your custom model path if trained
YOLO_MODEL = "yolov8n.pt"

# Classes YOLO should track (COCO IDs: 0=person, 32=sports ball …)
# Set to None to track all classes
TARGET_CLASSES = None

# Camera horizontal FOV in degrees — measure or get from spec sheet
CAMERA_HFOV = 60.0

# Colours for the overlay
COLOR_BOX    = (0,   255,   0)
COLOR_CENTER = (0,   0,   255)
COLOR_PRED   = (255, 165,   0)
COLOR_TRACK  = (255, 255,   0)

# ──────────────────────────────────────────────────────────────────────

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--port",            default="/dev/serial0",
                   help="UART port for ESP32")
    p.add_argument("--lidar-port",      default="/dev/ttyUSB0",
                   help="Serial port for RPLiDAR")
    p.add_argument("--cam-left",        type=int, default=0)
    p.add_argument("--cam-right",       type=int, default=1)
    p.add_argument("--no-display",      action="store_true",
                   help="Disable OpenCV window (headless mode)")
    p.add_argument("--manual-exposure", action="store_true",
                   help="Disable camera auto-exposure (use software AE)")
    return p.parse_args()


# ──────────────────────────────────────────────────────────────────────
# Overlay helpers
# ──────────────────────────────────────────────────────────────────────

def draw_crosshair(frame, cx, cy, color, size=15):
    cv2.line(frame, (cx - size, cy), (cx + size, cy), color, 1)
    cv2.line(frame, (cx, cy - size), (cx, cy + size), color, 1)


def draw_target_info(frame, box, track_id, dist_fused, cx, cy, pred_x, pred_y):
    x1, y1, x2, y2 = map(int, box)

    # Bounding box
    cv2.rectangle(frame, (x1, y1), (x2, y2), COLOR_BOX, 2)

    # Label
    label = f"ID:{track_id}  {dist_fused:.2f}m" if dist_fused > 0 else f"ID:{track_id}"
    cv2.putText(frame, label, (x1, y1 - 8),
                cv2.FONT_HERSHEY_SIMPLEX, 0.55, COLOR_BOX, 1)

    # Detected centre
    draw_crosshair(frame, cx, cy, COLOR_CENTER)

    # Kalman predicted centre
    draw_crosshair(frame, pred_x, pred_y, COLOR_PRED)

    # Line from detected to predicted
    cv2.line(frame, (cx, cy), (pred_x, pred_y), COLOR_TRACK, 1)


_CONDITION_LABELS = {
    LightCondition.DARK:          ("DARK",          (80,  80,  200)),
    LightCondition.DIM:           ("DIM",            (120, 120, 200)),
    LightCondition.NORMAL:        ("NORMAL",         (80,  200,  80)),
    LightCondition.BRIGHT:        ("BRIGHT",         (0,   200, 200)),
    LightCondition.BACKLIT:       ("BACKLIT",        (0,   140, 255)),
    LightCondition.HIGH_CONTRAST: ("HIGH CONTRAST",  (200, 100,   0)),
}


def draw_hud(frame, fps, target_lost, condition: LightCondition):
    status = "TRACKING" if not target_lost else "SEARCHING"
    color  = (0, 255, 0) if not target_lost else (0, 0, 255)

    cond_label, cond_color = _CONDITION_LABELS.get(
        condition, ("UNKNOWN", (150, 150, 150))
    )

    cv2.putText(frame, f"FPS: {fps:.1f}", (10, 20),
                cv2.FONT_HERSHEY_SIMPLEX, 0.55, (200, 200, 200), 1)
    cv2.putText(frame, status, (10, 45),
                cv2.FONT_HERSHEY_SIMPLEX, 0.65, color, 2)
    cv2.putText(frame, f"LIGHT: {cond_label}", (10, 70),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, cond_color, 1)

    # Frame centre reticle
    draw_crosshair(frame, CENTER_X, CENTER_Y, (80, 80, 80), size=20)


# ──────────────────────────────────────────────────────────────────────
# Target selection
# ──────────────────────────────────────────────────────────────────────

def pick_primary_target(results):
    """
    From all detections, pick the one closest to the frame centre.
    Returns (box, track_id, cx, cy) or None.
    """
    best      = None
    best_dist = float("inf")

    boxes = results[0].boxes
    if boxes is None:
        return None

    for box in boxes:
        if TARGET_CLASSES is not None:
            cls = int(box.cls[0])
            if cls not in TARGET_CLASSES:
                continue

        x1, y1, x2, y2 = box.xyxy[0].tolist()
        cx = int((x1 + x2) / 2)
        cy = int((y1 + y2) / 2)

        d = ((cx - CENTER_X) ** 2 + (cy - CENTER_Y) ** 2) ** 0.5

        if d < best_dist:
            best_dist = d
            track_id  = int(box.id[0]) if box.id is not None else -1
            best = ([x1, y1, x2, y2], track_id, cx, cy)

    return best


# ──────────────────────────────────────────────────────────────────────
# Main
# ──────────────────────────────────────────────────────────────────────

def main():
    args = parse_args()

    print("=== AI Tracking Turret — Raspberry Pi ===")

    # ── Init subsystems ───────────────────────────────────────────────
    camera   = StereoCamera(
        cam_left_id   = args.cam_left,
        cam_right_id  = args.cam_right,
        width         = FRAME_W,
        height        = FRAME_H,
        auto_exposure = not args.manual_exposure,
    )
    enhancer = ImageEnhancer()
    depth    = DepthEstimator(camera.focal_len, camera.baseline)
    lidar    = LidarReader(port=args.lidar_port)
    tracker  = FusionTracker()
    uart     = UartSender(port=args.port)
    model    = YOLO(YOLO_MODEL)

    lidar.start()
    uart.start()

    fps        = 0.0
    frame_time = time.time()
    condition  = LightCondition.NORMAL

    # Adapt YOLO confidence threshold based on lighting
    _CONF_BY_CONDITION = {
        LightCondition.DARK:          0.30,
        LightCondition.DIM:           0.35,
        LightCondition.NORMAL:        0.45,
        LightCondition.BRIGHT:        0.45,
        LightCondition.BACKLIT:       0.35,
        LightCondition.HIGH_CONTRAST: 0.40,
    }

    try:
        while True:
            # ── Grab stereo frames ────────────────────────────────────
            left, right = camera.read()
            if left is None:
                print("[Main] Camera read failed — retrying…")
                time.sleep(0.05)
                continue

            # ── Adaptive enhancement ──────────────────────────────────
            #    Derive params from left, apply identically to both
            #    so stereo L/R contrast stays matched for depth calc.
            enh_left, enh_right = enhancer.enhance_stereo(left, right)
            condition = enhancer.scene_condition(left)

            # Optionally drive camera exposure from scene brightness
            if args.manual_exposure:
                import numpy as _np
                camera.adjust_exposure(float(_np.mean(
                    cv2.cvtColor(left, cv2.COLOR_BGR2GRAY)
                )))

            conf_thresh = _CONF_BY_CONDITION.get(condition, 0.40)

            # ── YOLO on enhanced frame ────────────────────────────────
            results = model.track(
                enh_left,
                persist   = True,
                verbose   = False,
                classes   = TARGET_CLASSES,
                conf      = conf_thresh,
                iou       = 0.5,
            )

            target = pick_primary_target(results)

            if target is not None:
                box, track_id, cx, cy = target

                # ── Stereo depth on enhanced pair ─────────────────────
                depth.compute(enh_left, enh_right)
                stereo_dist = depth.depth_at(cx, cy)

                # ── LiDAR distance ────────────────────────────────────
                lidar_dist = lidar.distance_for_pixel(
                    cx, FRAME_W, CAMERA_HFOV
                )

                # ── Fuse + Kalman update ──────────────────────────────
                pred_x, pred_y, fused_dist = tracker.update(
                    cx, cy, stereo_dist, lidar_dist
                )

                # ── Send to ESP32 ─────────────────────────────────────
                uart.send(pred_x, pred_y, fused_dist)

                # ── Draw overlay on ENHANCED frame for visibility ──────
                if not args.no_display:
                    draw_target_info(
                        enh_left, box, track_id,
                        fused_dist, cx, cy, pred_x, pred_y
                    )

            else:
                # No detection — keep Kalman rolling
                pred_x, pred_y = tracker.predict_only()

                if tracker.target_lost:
                    uart.send_lost()
                    tracker.reset()

            # ── FPS + HUD ─────────────────────────────────────────────
            now        = time.time()
            fps        = 0.9 * fps + 0.1 * (1.0 / max(now - frame_time, 1e-6))
            frame_time = now

            if not args.no_display:
                draw_hud(enh_left, fps, tracker.target_lost, condition)
                cv2.imshow("Turret — Left Camera (enhanced)", enh_left)
                cv2.imshow("Depth Map", depth.colormap())

                key = cv2.waitKey(1) & 0xFF
                if key == ord('q'):
                    break

    except KeyboardInterrupt:
        print("\n[Main] Interrupted by user.")

    finally:
        lidar.stop()
        uart.stop()
        camera.release()
        cv2.destroyAllWindows()
        print("[Main] Shutdown complete.")


if __name__ == "__main__":
    main()
